// import { AbstractControl } from '@angular/forms';

// export function gmailValidator(control: AbstractControl): { [key: string]: any } | null {
//   const email = control.value;
//   if (!email || !email.endsWith('@gmail.com')) {
//     return { 'invalidGmail': { message: 'Email must end with @gmail.com' } };
//   }
//   return null; // Validation passed
// }

// export function passwordValidator(control: AbstractControl): { [key: string]: any } | null {
//   const password = control.value;
//   const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}$/;
//   // Explanation of regex:
//   // (?=.*[a-z])      : At least one lowercase letter
//   // (?=.*[A-Z])      : At least one uppercase letter
//   // (?=.*\d)         : At least one digit
//   // (?=.*[$@$!%*?&]) : At least one special character
//   // [A-Za-z\d$@$!%*?&]{8,} : Match characters in the given range at least 8 times
//   if (password && regex.test(password)) {
//     return null; // Validation passed
//   }
//   return { 'invalidPassword': true }; // Validation failed
// }

