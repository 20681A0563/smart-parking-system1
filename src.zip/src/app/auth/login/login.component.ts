import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UsersService } from 'src/app/services/users.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  form: FormGroup;
  invalidLogin: boolean = false;

  constructor(private formBuilder: FormBuilder, private usersService: UsersService, public router: Router) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email, Validators.pattern(/^[a-zA-Z0-9._%+-]+@gmail\.com$(?!.*\w)/) ]],
      password: ['', [Validators.required, Validators.pattern(/[!@#$%^&*(),.?":{}|<>]/)]]
    });
    this.checkLogin();
  }

  onSubmit() {
    if (this.form.valid) {
      var loginJson = JSON.stringify(this.form.value);
      this.usersService.loginCheck(loginJson)
        .subscribe(data => {
          if (data == true) {
            alert("Login successful");
            var jsonData = JSON.parse(loginJson);
            this.storeLogin(jsonData['email']);
            this.router.navigate(['/dashboard']);
          } else {
            alert("Invalid Login");
          }
        })
    } else {
      // Mark all form controls as touched to display validation errors in the template
      this.markFormGroupTouched(this.form);
    }
  }

  // Function to mark all form controls as touched
  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();

      // If control is a nested FormGroup, recursively mark its controls as touched
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  storeLogin(email) {
    sessionStorage.setItem("email", email);
  }

  checkLogin() {
    if (sessionStorage.length != 0) {
      this.router.navigate(['/']);
    }
  }
}
